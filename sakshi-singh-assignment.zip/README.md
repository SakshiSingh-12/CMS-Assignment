# Author

- Name: Sakshi Singh
- Email: sakshisngjnp12@gmail.com
- GitHub: https://github.com/SakshiSingh-12

# Headless CMS Portal

This project is a rudimentary headless CMS with basic CRUD functionality, similar to a very basic version of strapi.js. It was developed as part of the VAHAN SDE intern position assignment.

## Problem Statement

The goal of this project is to allow end users to create different entities from the frontend by specifying its attributes and their types. For example, a "Person" is an entity with attributes name (string), email (string), mobileNumber (number), and dateOfBirth (Date).

When an entity is created from the frontend, the app automatically creates a table definition, depending on the attributes in an RDBMS (MySQL or PostgreSQL only).

After creating an entity, users should be able to Create, Read, Update, and Delete data in that entity from the frontend itself. For instance, a user should be able to create an entry in the "Person" entity using "Ketan" as the name, "ketan@test.com" as the email, "9876543210" as the mobile number, and "1-Jan-1990" as the date of birth. Users should also be able to add, update existing entries, view created entries, and delete an existing entry.

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details.
